#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("GRU\n");
    return 0;
}
