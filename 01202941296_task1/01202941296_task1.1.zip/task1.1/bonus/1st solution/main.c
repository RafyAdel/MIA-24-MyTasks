#include <stdio.h>
#include <stdlib.h>

int main()
{  printf("*****\t****  \t*    *\n");
   printf("*    \t*   * \t*    *\n");
   printf("*  **\t***** \t*    *\n");
   printf("*   *\t*   * \t*    *\n");
   printf("*****\t*    *\t******\n");
    return 0;
}
