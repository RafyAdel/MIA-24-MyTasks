#include <stdio.h>
#include <stdlib.h>
#define initialVelocity 30
#define initialAngle 46

int main()
{
    float mpu6050[10] = {0.0, 11.68, 18.95, 23.56, 25.72, 25.38, 22.65, 18.01, 10.14, -0.26};
    float bno55[10] = {0.0,9.49, 16.36, 21.2, 23.16, 22.8, 19.5, 14.85, 6.79, -2.69};
    //fair
    float fair[10];
    printf("fair results are : \n");
    for (int i=0;i<10;i++)
    {
        fair[i]=(mpu6050[i]+bno55[i])/2;
        printf("%f ,",fair[i]);
    }
    printf("\n");
    //good
    float good[10];
    printf("good results are : \n");
    for (int i=0;i<10;i++)
    {
        good[i]=(mpu6050[i]*0.78+bno55[i]*0.92)/(0.92+0.78);
        /*formula to calculate the avg taking into consideration the accuracies is
        Average = (Reading1 * Accuracy1 + Reading2 * Accuracy2) / (Accuracy1 + Accuracy2)*/
        printf("%f ,",good[i]);
    }
    printf("\n");
    //hero


    return 0;
}
